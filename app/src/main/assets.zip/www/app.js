$(document).ready(function() {

   var error = $('.error');
   var wait = $('.wait');
   var success = $('.success');
   var message = {
      error: function(text){
         error.removeClass('hide-message');
         wait.addClass('hide-message');
         success.addClass('hide-success');
      },
      wait: function() {
         wait.removeClass('hide-message');
         error.addClass('hide-message');
      },
      success: function() {
         error.addClass('hide-message');
         wait.addClass('hide-message');
         setTimeout(function(){
            success.removeClass('hide-success');
         }, 200);
      },
      hideSuccess: function() {
         success.addClass('hide-success');
      },
      hide: function(){
         error.addClass('hide-message');
         wait.addClass('hide-message');
      }
   };

   var loader = $('.loading-bg');
   var loading = {
      show: function(){
         loader.removeClass('hide-loading');
      },
      hide: function(){
         loader.addClass('hide-loading');
      }
   };

   var app = {
      reset: function() {
         loading.hide();
         message.hide();
         message.hideSuccess();
      },
      fail: function() {
         app.reset();
         loading.show();
         setTimeout(function(){
            message.error();
            loading.hide();
         },2000);
      },
      wait: function() {
         app.reset();
         loading.show();
         setTimeout(function(){
            message.wait();
         },1000);
      },
      success: function() {
         loading.hide();
         message.success();
      }
   };

   function buttonClick(){
      Android.showToast("balls deep");
      app.fail();
   }

   $(document).on('click','#button',function(){
      buttonClick();
   });

   window.message = message;
   window.loading = loading;
   window.app = app;
});
